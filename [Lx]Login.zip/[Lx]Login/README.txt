LINUX Game - Account System (MTA:SA resource "linux_auth")
==========================================================

NOTE: the tables are now lg_accounts / lg_logins / lg_flags. The old table lg_users (previous version) is no longer used - you can drop it.

DATABASE (MySQL / XAMPP)
 1. Start "MySQL" in the XAMPP Control Panel.
 2. Open http://localhost/phpmyadmin -> SQL tab -> run database.sql (creates the database "linux_game").
 3. Edit CFG.mysql at the top of server.lua if your host/user/password/database differ.
    (XAMPP default: host 127.0.0.1, port 3306, user root, empty password.)
 The table "lg_users" is created automatically on first start.
 Live server: do NOT use root without a password - create a dedicated MySQL user with rights only on this database.

INSTALL
 1. Copy the folder "linux_auth" to  mods/deathmatch/resources/
 2. In the server console:   refresh
                             start linux_auth
                             aclrequest allow linux_auth all     (needed for addAccount / logIn / fetchRemote ...)
 3. Add  <resource src="linux_auth" startup="1"/>  to mtaserver.conf to start it automatically.
 4. Stop resources that auto-spawn players (spawnmanager / freeroam / play ...) - this resource spawns the player after login.

CONFIG
 - server.lua  top table CFG  : spawn point, limits, lock time, Telegram bot, multi-account rules, maintenance, announcements ...
 - ui/script.js CONFIG.links  : Discord / Telegram / Instagram / TeamSpeak links
 - ui/bg.jpg, ui/logo.png     : replace with your own images (same names)
 - Music: put music.mp3 in the resource folder and un-comment the <file src="music.mp3"/> line in meta.xml.
   If the file is missing the music button hides itself.
   Controls: click the speaker = on/off, hover = volume slider, mouse wheel = volume, key M = mute.
   Volume and mute are remembered on the player's PC; music fades in/out smoothly and ducks during the welcome screen.

ADMIN COMMANDS (ACL group "Admin" or console)
 /maintenance [on|off]        only staff can log in, nobody can register
 /lgban <user> [reason]  /lgunban <user>  /lgdelete <user>  /lgmulti <user>  /lgflags

FOR OTHER RESOURCES
 - Player data:  getElementData(player, "lg.id") / getElementData(player, "lg.username")
 - Event:        addEvent("lg:onLogin") addEventHandler("lg:onLogin", root, function(userId, username) end)
 - With CFG.mtaAccounts = true the player is also logged into a normal MTA account with the same name.

TELEGRAM VERIFICATION (replaces email)
 Players register with a PHONE NUMBER. A Cloudflare Worker bot (folder linux_bot) checks the forced channel membership,
 asks the player to share his own phone number, compares it with the number typed in the game and links the Telegram account.
 Recovery codes / "forgot username" are sent to that Telegram chat.
 Set CFG.telegram (api, key, bot) at the top of server.lua - setup steps are in linux_bot/README.txt.
 Server in Iran / getting 403: the server sends browser-like headers and can fall back to several worker URLs (CFG.telegram.api is a list).
 Run  lgtest  in the server console to see exactly what each URL answers.

ONE ACCOUNT PER PC + MULTI-ACCOUNT DETECTION
 - serial, phone and Telegram id are UNIQUE in the database: one PC / one phone / one Telegram = one account.
 - Registration is refused when the PC already owns an account, or hosted one in the last 30 days (CFG.multi.strictSerialHistory),
   so "move the account to a new PC, then register again on the old PC" does not work.
 - Recovery to a PC that already owns another account is refused.
 - Every login is logged (lg_logins). Suspicious events are stored in lg_flags and shown to online staff when weight >= 50:
     MULTI_REGISTER 80   PC that owns/hosted an account tried to register
     PHONE_REUSE    80   phone number of an existing account used again
     SHARED_DEVICE  60   PC of account A tried to log into / recover account B
     SERIAL_SHARED 100   two accounts were used from the same PC
     IP_ONLINE      40   two accounts online from the same IP
     IP_SHARED      20   two accounts used the same IP recently (stored silently: families / internet cafes)
 - Staff commands: /lgmulti <user> (linked accounts by PC / IP + flags), /lgflags (last flags),
                   /lgtest (Telegram connection test), /lgdelete <user> (frees username, phone, Telegram and PC), /lgban, /lgunban, /maintenance

SECURITY NOTES
 - Passwords are stored as bcrypt hashes (MySQL password stays in server.lua, which is never sent to players). "Remember me" stores the username and the password on the player's own PC; the password is encrypted (TEA) with a random per-PC key.
   This protects against casual snooping only - do not use it on shared computers. Unticking it deletes the saved data.
 - Wrong-password lock is enforced on the server (per serial), not only in the UI.
 - A new PC must be linked through the "Account Recovery" tab (code sent to the linked Telegram).
